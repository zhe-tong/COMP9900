from flask import Flask, render_template, request, session
import until
import json
import os
import base64

app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(24)


@app.route('/')
def index():
    type = request.args.get('type')
    if type == None:
        sql = 'select id,img,name,username from foodinfo'
        res = until.serch(sql)
        data = []
        for i in res:
            scnumber = until.serch('select count(id) from tb_usersc where foodid = {0}'.format(i[0]))[0][0]
            likenumber = until.serch('select count(id) from tb_userlike where foodid = {0}'.format(i[0]))[0][0]
            s = {
                "id": i[0],
                "img": i[1],
                "name": i[2],
                "username": i[3],
                "scnumber": scnumber,
                "likenumber": likenumber,
            }
            data.append(s)
        return render_template('index.html', data=data)
    else:
        sql = 'select id,img,name,username from foodinfo where type = "{0}"'.format(type)
        res = until.serch(sql)
        data = []
        for i in res:
            scnumber = until.serch('select count(id) from tb_usersc where foodid = {0}'.format(i[0]))[0][0]
            s = {
                "id": i[0],
                "img": i[1],
                "name": i[2],
                "username": i[3],
                "scnumber": scnumber,
            }
            data.append(s)
        return render_template('index.html', data=data)


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')
    else:
        email = request.form.get('email')
        password = request.form.get('password')
        data = until.login(email, password)
        if data['code'] == 200:
            session['userid'] = data['userid']
        return data


@app.route('/signin', methods=['GET', 'POST'])
def signin():
    if request.method == 'GET':
        return render_template('signin.html')
    else:
        name = request.form.get('name')
        password = request.form.get('password')
        rpassword = request.form.get('rpassword')
        email = request.form.get('email')
        if password != rpassword:
            data = {
                'code': 202,
                'msg': "输入的两次密码不一致"
            }
            return data
        else:
            data = until.signup(name, email, password)
            return data


@app.route('/searchjg', methods=['GET', 'POST'])
def searchjg():
    """
    首页搜索
    :return:
    """
    key = request.args.get('key')
    data = until.searchjg(key)
    return render_template('searchjg.html', data=data)


@app.route('/recipe', methods=['GET', 'POST'])
def recipe():
    if request.method == "GET":
        foodid = request.args.get('foodid')
        data = until.foodinfo(foodid)
        other = until.foodfind(foodid)
        plinfo = until.getplinfo(foodid)
        return render_template('recipe.html', data=data, plinfo=plinfo, other=other)
    else:
        data = request.form.get('data')
        data = json.loads(data)
        data = until.userpl(data['userid'], data['foodid'], data['content'])
        return data


@app.route('/usersc', methods=['GET', 'POST'])
def usersc():
    data = request.form.get('data')
    data = json.loads(data)
    data = until.usersc(data['userid'], data['foodid'])
    return data


@app.route('/userlike', methods=['GET', 'POST'])
def userlike():
    data = request.form.get('data')
    data = json.loads(data)
    data = until.userlike(data['userid'], data['foodid'])
    return data


@app.route('/usersubscribe', methods=['GET', 'POST'])
def usersubscribe():
    data = request.form.get('data')
    data = json.loads(data)
    data = until.usersubscribe(data['userid'], data['fuserid'])
    return data


@app.route('/recommendation', methods=['GET', 'POST'])
def recommendation():
    userid = session.get('userid')
    data = until.search(userid)
    return render_template('recommendation.html', data=data)


@app.route('/profile', methods=['GET', 'POST'])
def profile():
    userid = session.get('userid')
    splist = until.getuserspinfo(userid)
    userinfo = until.serch('select username,email from tb_user where id = {0}'.format(userid))[0]
    data = {
        'splist': splist,
        'userinfo': {
            'username': userinfo[0],
            'email': userinfo[1],
        }
    }
    return render_template('profile.html', data=data)


@app.route('/resetpassword', methods=['GET', 'POST'])
def resetpassword():
    if request.method == 'GET':
        return render_template('resetpassword.html')
    else:
        email = request.form.get('email')
        password = request.form.get('password')
        rpassword = request.form.get('rpassword')
        if password != rpassword:
            data = {
                'code': 202,
                'msg': "The passwords entered twice do not match"
            }
            return data
        else:
            data = until.resetpassword(email, password)
            if data['code'] == 200:
                session.clear()
            return data


@app.route('/Mysubscription', methods=['GET', 'POST'])
def Mysubscription():
    userid = session.get('userid')
    data = until.Mysubscription(userid)
    return render_template('Mysubscription.html', data=data)


@app.route('/Mycomments', methods=['GET', 'POST'])
def Mycomments():
    userid = session.get('userid')
    pllist = until.getuserplinfo(userid)
    return render_template('Mycomments.html', data=pllist)


@app.route('/Mysaved', methods=['GET', 'POST'])
def Mysaved():
    userid = session.get('userid')
    sclist = until.getuserscinfo(userid)
    data = {
        'sclist': sclist
    }
    return render_template('Mysaved.html', data=data)


@app.route('/delusersc', methods=['GET', 'POST'])
def delusersc():
    data = request.form.get('data')
    data = json.loads(data)
    data = until.delusersc(data['scid'])
    return data


@app.route('/deluserpl', methods=['GET', 'POST'])
def deluserpl():
    data = request.form.get('data')
    data = json.loads(data)
    data = until.deluserpl(data['plid'])
    return data


@app.route('/delusersp', methods=['GET', 'POST'])
def delusersp():
    data = request.form.get('data')
    data = json.loads(data)
    data = until.delusersp(data['foodid'])
    return data


@app.route('/userupdatesp', methods=['GET', 'POST'])
def userupdatesp():
    if request.method == 'GET':
        return render_template('userupdatesp.html')
    else:
        import time
        type = request.form.get('sel')
        userid = session.get('userid')
        cpname = request.form.get('cpname')
        make = request.form.get('make')
        cl = request.form.get('cl')
        img = request.files['img']
        imgpath = 'static/image/' + img.filename
        img.save(imgpath)
        pic = open(imgpath, "rb")
        pic_base64 = str(base64.b64encode(pic.read())).split('\'')[1]
        time = time.strftime('%Y-%m-%d', time.localtime())
        until.userupdatesp(
            userid, cpname, make, cl, pic_base64, time, type
        )
        data = {
            'msg': "Success"
        }
        return data


@app.route('/change', methods=['GET', 'POST'])
def change():
    foodid = request.args.get('foodid')
    data = until.changeinfo(foodid)
    return render_template('change.html', data=data)


@app.route('/userspcahnge', methods=['GET', 'POST'])
def userspcahnge():
    import time
    fooid = request.form.get('fooid')
    cpname = request.form.get('cpname')
    make = request.form.get('make')
    cl = request.form.get('cl')
    type = request.form.get('sel')
    try:
        img = request.files['img']
        imgpath = 'static/image/' + img.filename
        img.save(imgpath)
        pic = open(imgpath, "rb")
        pic_base64 = str(base64.b64encode(pic.read())).split('\'')[1]
    except:
        pic_base64 = request.form.get('imgurl')
    time = time.strftime('%Y-%m-%d', time.localtime())
    until.userspcahnge(
        fooid, cpname, make, cl, pic_base64, time
    )
    data = {
        'msg': "Success"
    }
    return data



if __name__ == '__main__':
    app.run()
