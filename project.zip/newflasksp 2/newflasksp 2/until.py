import random

import pymysql
import numpy as np


def coon():
    con = pymysql.connect(host='127.0.0.1'  # connection address, 127.0.0.1 by default
                          , user='root'  # database username
                          , passwd=''  # datbase password
                          , port=3306  # port, 3306 by default
                          , db='food'  # datbase name
                          , charset='utf8'  # encoding
                          )
    cur = con.cursor()  # create cursor
    return con, cur


def close():
    con, cur = coon()
    cur.close()
    con.close()


def serch(sql):
    con, cur = coon()
    cur.execute(sql)
    res = cur.fetchall()
    close()
    return res


def insert(sql):
    con, cur = coon()
    cur.execute(sql)
    con.commit()
    close()


def login(email, passwrod):
    sql = 'select * from tb_user where email = "{0}"'.format(email)
    res = serch(sql)
    if res != ():
        if res[0][3] == passwrod:
            data = {
                'code': 200,
                'msg': "success",
                'userid': res[0][0]
            }
            return data
        else:
            data = {
                "code": 202,
                "msg": "incorrect password"
            }
            return data
    else:
        data = {
            "code": 201,
            "msg": "this user does not exist"
        }
        return data


def signup(username, email, passwrod):
    sql = 'select * from tb_user where email  = "{0}"'.format(email)
    res = serch(sql)
    if res != ():
        data = {
            'code': 201,
            'msg': "this user has been signed up！"
        }
        return data
    else:
        sql = "insert into tb_user(`username`, `email`, `password`) values('%s','%s','%s')" % (
            username, email, passwrod)
        insert(sql)
        data = {
            'code': 200,
            'msg': "success",
        }
        return data


def getfoodinfo():
    sql = 'select id,img,name,username from foodinfo'
    res = serch(sql)
    data = []
    for i in res:
        scnumber = serch('select count(id) from tb_usersc where foodid = {0}'.format(i[0]))[0][0]
        s = {
            "id": i[0],
            "img": i[1],
            "title": i[2],
            "username": i[3],
            "scnumber": scnumber,
        }
        data.append(s)
    return data


def gettypeinfo(type):
    sql = 'select id,img,name,username from foodinfo where type like "%{0}%"'.format(type)
    res = serch(sql)
    data = []
    for i in res:
        scnumber = serch('select count(id) from tb_usersc where foodid = {0}'.format(i[0]))[0][0]
        s = {
            "id": i[0],
            "img": i[1],
            "title": i[2],
            "username": i[3],
            "scnumber": scnumber,
        }

        data.append(s)
    return data


def search(userid):
    sql = 'select foodid from tb_usersc where userid = {0}'.format(userid)
    res = serch(sql)
    data = []
    rdata = []
    for i in res:
        type = serch('select type from foodinfo where id = {0}'.format(i[0]))[0][0]
        if type not in data:
            data.append(type)
    for x in data:
        sql = 'select id,img,name,username from foodinfo   where type like "%{0}%" ORDER BY RAND() LIMIT 10'.format(x)
        res = serch(sql)
        for i in res:
            scnumber = serch('select count(id) from tb_usersc where foodid = {0}'.format(i[0]))[0][0]
            likecount = serch('select count(id) from tb_userlike where foodid = {0}'.format(i[0]))[0][0]
            if likecount == ():
                likecount = 0
            s = {
                "id": i[0],
                "img": i[1],
                "title": i[2],
                "username": i[3],
                "scnumber": scnumber,
                "likecount":likecount
            }
            rdata.append(s)
    return rdata


def foodinfo(foodid):
    sql = 'select * from foodinfo where id = {0}'.format(foodid)
    res = serch(sql)[0]
    likecount = serch('select count(id) from tb_userlike where foodid = {0}'.format(foodid))[0][0]
    if likecount == ():
        likecount = 0
    data = {
        'id': res[0],
        'username': res[1],
        'userid': res[2],
        'img': res[3],
        'name': res[4],
        'make': res[5].split(','),
        'cl': res[6].split(','),
        'likecount': likecount
    }
    return data


def foodfind(foodid):
    sql = 'select cl from foodinfo where id = {0}'.format(foodid)
    res = serch(sql)[0][0].split(',')
    data = []
    infolist = []
    cl_r = 0
    for x in res:
        list1 = serch('select id from foodinfo where cl like  "%{0}%"'.format(x))
        for i in list1:
            if i[0] not in data and foodid != str(i[0]):
                data.append(i[0])
    for x in data:
        list2 = serch('select id,img,name,username,cl from foodinfo where id =  "{0}"'.format(x))
        for i in list2:
            scnumber = serch('select count(id) from tb_usersc where foodid = {0}'.format(i[0]))[0][0]
            cl_p = i[4].split(',')
            random.shuffle(res)
            for y in res:
                if y in cl_p:
                    cl_r = y
                    break
            s = {
                "id": i[0],
                "img": i[1],
                "title": i[2],
                "username": i[3],
                "scnumber": scnumber,
                'cl':cl_r
            }
            infolist.append(s)
    return infolist


def userpl(userid, foodid, content):
    import time
    if content == " ":
        data = {
            'code': 201,
            'msg': "comment cannot be empty"
        }
        return data
    time = time.strftime('%Y-%m-%d', time.localtime())
    sql = 'insert into tb_foodplinfo(userid,foodid,content,time) values("%s","%s","%s","%s")' % (
        userid, foodid, content, time
    )
    insert(sql)
    data = {
        'code': 200,
        'msg': "success"
    }
    return data


def usersc(userid, foodid):
    sql = 'select * from tb_usersc where userid = {0} and foodid = {1}'.format(userid, foodid)
    res = serch(sql)
    if res != ():
        data = {
            'msg': "Do not repeat saving"
        }
        return data
    sql = 'insert into tb_usersc(userid,foodid) values ("%s","%s")' % (userid, foodid)
    insert(sql)
    data = {
        'msg': "Saved"
    }
    return data


def userlike(userid, foodid):
    sql = 'select * from tb_userlike where userid = {0} and foodid = {1}'.format(userid, foodid)
    res = serch(sql)
    if res != ():
        insert('delete from tb_userlike where userid = {0} and foodid = {1}'.format(userid, foodid))
        data = {
            'msg': "Canceled"
        }
        return data
    sql = 'insert into tb_userlike(userid,foodid) values ("%s","%s")' % (userid, foodid)
    insert(sql)
    data = {
        'msg': "Liked"
    }
    return data


def usersubscribe(userid, fuserid):
    sql = 'select * from tb_usersubscribe where userid = {0} and fuserid = {1}'.format(userid, fuserid)
    res = serch(sql)
    if res != ():
        insert('delete from tb_usersubscribe where userid = {0} and fuserid = {1}'.format(userid, fuserid))
        data = {
            'msg': "Cancel your subscription"
        }
        return data
    sql = 'insert into tb_usersubscribe(userid,fuserid) values ("%s","%s")' % (userid, fuserid)
    insert(sql)
    data = {
        'msg': "Subscription successful"
    }
    return data


def getplinfo(foodid):
    sql = 'select * from tb_foodplinfo where foodid = {0}'.format(foodid)
    res = serch(sql)
    data = []
    for i in res:
        username = serch('select username from tb_user where id = {0}'.format(i[1]))[0][0]
        s = {
            'username': username,
            'time': i[4],
            'content': i[3]
        }
        data.append(s)
    return data


def getuserspinfo(userid):
    sql = 'select * from foodinfo where userid = {0}'.format(userid)
    res = serch(sql)
    data = []
    for i in res:
        plcount = serch('select count(id) from tb_foodplinfo where foodid = {0}'.format(i[0]))[0][0]
        s = {
            'id': i[0],
            'img': i[3],
            'foodname': i[4],
            'plcount': plcount
        }
        data.append(s)
    return data


def getuserscinfo(userid):
    sql = 'select * from tb_usersc where userid = {0}'.format(userid)
    res = serch(sql)
    data = []
    for i in res:
        foodinfo = serch('select name,img from foodinfo where id = {0}'.format(i[1]))[0]
        s = {
            'id': i[0],
            'foodname': foodinfo[0],
            'foodimg': foodinfo[1],
            'foodid': i[1]
        }
        data.append(s)
    return data


def getuserplinfo(userid):
    sql = 'select * from tb_foodplinfo where userid = {0}'.format(userid)
    res = serch(sql)
    data = []
    for i in res:
        foodname = serch('select name from foodinfo where id = {0}'.format(i[2]))[0][0]
        s = {
            'foodname': foodname,
            'id': i[0],
            'cotent': i[3],
            'time': i[4],
            'foodid': i[2]
        }
        data.append(s)
    return data


def delusersp(foodid):
    sql = 'DELETE FROM foodinfo WHERE id = {0}'.format(foodid)
    insert(sql)
    sql = 'DELETE FROM tb_foodplinfo WHERE foodid = {0}'.format(foodid)
    insert(sql)
    data = {
        'msg': "Deleted"
    }
    return data


def deluserpl(plid):
    sql = 'DELETE FROM tb_foodplinfo WHERE id = {0}'.format(plid)
    insert(sql)
    data = {
        'msg': "Deleted"
    }
    return data


def delusersc(scid):
    sql = 'DELETE FROM tb_usersc WHERE id = {0}'.format(scid)
    insert(sql)
    data = {
        'msg': "Canceled"
    }
    return data


def userupdatesp(userid, cpname, make, cl, pic_base64, time, type):
    username = serch('select username from tb_user where id = {0}'.format(userid))[0][0]
    sql = 'insert into foodinfo(`username`, `userid`, `img`, `name`,  `make`, `cl`, `time`,`type`) values ("%s","%s","%s","%s","%s","%s","%s","%s")' % (
        username, userid, pic_base64, cpname, make.replace('|', ','), cl.replace('|', ','),
        time, type
    )
    insert(sql)


def changeinfo(foodid):
    sql = 'select * from foodinfo where id = {0}'.format(foodid)
    res = serch(sql)[0]
    data = {
        'id': res[0],
        'username': res[1],
        'userid': res[2],
        'img': res[3],
        'name': res[4],
        'make': res[5].replace(',', '|'),
        'cl': res[6].replace(',', '|'),
        'type': res[8]
    }
    return data


def userspcahnge(id, cpname, make, cl, pic_base64, time):
    sql = ' UPDATE foodinfo SET `name`= "{0}", `make`="{1}",`cl`="{2}", `img`="{3}", `time`="{4}" WHERE id="{5}"'.format(
        cpname, make.replace('|', ','), cl.replace('|', ','), pic_base64, time, id
    )
    insert(sql)


def searchjg(key):
    sql = 'select * from foodinfo where name like "%{0}%"  or cl like "%{1}%"'.format(key, key)
    res = serch(sql)
    data = []
    for i in res:
        s = {
            'id': i[0],
            'username': i[1],
            'userid': i[2],
            'img': i[3],
            'name': i[4],
        }
        data.append(s)
    return data


def resetpassword(email, password):
    sql = 'update tb_user set password = "{0}" where email = "{1}"'.format(password, email)
    insert(sql)
    data = {
        'code': 200,
        'msg': "The password was successfully changed"
    }
    return data


def Mysubscription(userid):
    sql = 'select fuserid from tb_usersubscribe where userid = {0}'.format(userid)
    res = serch(sql)
    result = []
    for i in res:
        data = []
        sql = 'select * from foodinfo where userid = {0} order by time DESC'.format(i[0])
        res = serch(sql)
        for x in res:
            s = {
                'id': x[0],
                'username': x[1],
                'userid': x[2],
                'img': x[3],
                'name': x[4],
                'make': x[5].replace(',', '|'),
                'cl': x[6].replace(',', '|'),
                'time': x[7],
                'type': x[8]
            }
            data.append(s)
        result.append(data)
    return result
