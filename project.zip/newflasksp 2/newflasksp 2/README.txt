Code Structure
- static---------------- Static Files of the website
  - css----------------- styling
  - assets-------------- default resources used in website
  - images-------------- stores images used in website
  - js------------------ bootstrap and jquery scripts

- templates------------- HTML pages
  - base.html----------- base elements of the head of pages
  - index.html---------- landing page of website
  - login.html---------- login page
  - signup.html--------- signup page
  - resetpassword.html-- resetting user's password page
  - profile.html-------- user's profile page
  - userupdatesp.html--- recipe creating and uploading page
  - change.html--------- recipe editing page
  - recipe.html--------- recipe detail page
  - searchjg.html------- searching page
  - recommendation.html- recommendation page
  - Mysaved.html-------- user's saved recipes
  - Mysubscription.html- user's subscription
  - Mycommonts.html----- user's conmments
  
- app.py---------------- Main Flask Application Code     
- until.py-------------- mysql configuration and back-end functions
- food.sql-------------- dumped sql file for importing into database when required

Istallation
We recommend you run this app on Python 3.9 with the dependencies listed below, make sure you have pip package manager to install all of the requirement packages for application (comes by default with python).

You will also need MySQL installed in system to run the application and optionally Apache server to interact with database from phpMyAdmin. Install XAMPP server from 8.1.6 from https://www.apachefriends.org/download.html

Usage
Step 1 : Open the path of this folder and run the following command in the terminal. This will install all the required packages.

$ pip install flask
$ pip install json
$ pip install os
$ pip install base64
$ pip install pymysql
$ pip install numpy
$ pip install random

Step 2:

Start MySQL Server & Apache from Xampp
Adjust the username, password nad port number in until.py accroding to your MySQL configuration,
go to localhost/phpmyadmin
Create a database called 'food'
Click 'Import' from top navigation file
Under the 'File to Import', browse and select the 'food.sql' file present in this repo. This will import all tables into the database

Step 3 : Open terminal inside this repository in your local system and execute the following code (Note : if your python 3+ is configured to python3, replace python below with python3).

$ python app.py

This will start flask and give you the localhost url for the webapp, use the same to load the webapp.